   
    	<div class="page-header">
    		<h1>Grid columns<small> responsive columns</small></h1>
        </div>
        
        <div class="row-fluid">
           <div class="span12">
           		<h3 class="header">Full width column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. Phasellus dignissim sagittis felis vel rutrum. Sed eget mi in massa luctus aliquam. In tincidunt scelerisque turpis placerat interdum. Donec convallis diam dolor, eu mollis magna. Aliquam a ante risus. Aliquam dapibus, lacus eu tristique congue, eros enim tempor nisl, at tempus enim erat nec leo. Ut ac tellus purus, eget pulvinar mauris. Maecenas tincidunt lectus at purus adipiscing id dapibus lectus vestibulum. Praesent ac eros vel tellus pulvinar porttitor at non ante.
           </div>
          
        </div><!--/row-fluid-->
        
        
        
        <div class="row-fluid">
           <div class="span6">
           		<h3 class="header">1/2 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. Phasellus dignissim sagittis felis vel rutrum. Sed eget mi in massa luctus aliquam. In tincidunt scelerisque turpis placerat interdum.
           </div>
           <div class="span6">
           		<h3 class="header">1/2 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. Phasellus dignissim sagittis felis vel rutrum. Sed eget mi in massa luctus aliquam. In tincidunt scelerisque turpis placerat interdum.
           </div>
          
        </div><!--/row-fluid-->
        
        <div class="row-fluid">
           <div class="span4">
           		<h3 class="header">1/3 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
           <div class="span4">
           		<h3 class="header">1/3 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
           <div class="span4">
           		<h3 class="header">1/3 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
          
        </div><!--/row-fluid-->
        
        <div class="row-fluid">
           <div class="span3">
           		<h3 class="header">1/4 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
           <div class="span3">
           		<h3 class="header">1/4 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
           <div class="span3">
           		<h3 class="header">1/4 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
           <div class="span3">
           		<h3 class="header">1/4 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada aliquam vulputate. Cras pulvinar erat ac velit eleifend porttitor at eu diam. Praesent elit mi, mattis vitae accumsan bibendum, porttitor non neque. 
           </div>
          
        </div><!--/row-fluid-->
        
        
        <div class="row-fluid">
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
           </div>
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           </div>
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           </div>
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           </div>
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           </div>
           <div class="span2">
           		<h3 class="header">1/6 column
                    <span class="header-line"></span> 
                </h3>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
           </div>
          
        </div><!--/row-fluid-->